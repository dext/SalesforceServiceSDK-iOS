//
//  SCSIncomingCollectionViewCell.h
//  ServiceCommon
//
//  Created by Thomas Myrden on 2017-08-03.
//  Copyright © 2017 Salesforce.com. All rights reserved.
//

#import "SCSMessagingCollectionViewCell.h"

@interface SCSIncomingCollectionViewCell : SCSMessagingCollectionViewCell

@end
