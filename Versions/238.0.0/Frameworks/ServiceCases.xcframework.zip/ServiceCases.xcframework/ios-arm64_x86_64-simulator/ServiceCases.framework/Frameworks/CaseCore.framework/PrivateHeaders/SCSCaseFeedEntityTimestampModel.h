//
//  SCSCaseFeedEntityTimestamp.h
//  CaseCore
//
//  Created by Amit Gosar on 5/10/16.
//  Copyright © 2016 Salesforce.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SCSCaseFeedEntityModel.h"

@class SCCaseFeedItemModel;

NS_ASSUME_NONNULL_BEGIN

@interface SCSCaseFeedEntityTimestampModel : SCSCaseFeedEntityModel

@end

NS_ASSUME_NONNULL_END
